<?php
include "config.php";

$id = $_GET['id-delete'];
$deQuery = "DELETE FROM user WHERE user_id = '{$id}'";
mysqli_query($con,$deQuery);

header("Location: {$url}/admin/users.php");
mysqli_close($con);

?>