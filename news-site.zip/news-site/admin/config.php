<?php

$url = "http://localhost/php/news-site";

$con = mysqli_connect('localhost','root','','avro-news') or die('No Connection');


?>